Class BankAccount: 
                    
  Def __init__(self, account_number, account_holder_name, initial_balance=0.0):
    Self.__account_number = account_number
    Self.__account_holder_name = account_holder_name
    Self.__account_balance = initial_balance
 
  Def deposit(self, amount):
    If amount > 0:
      Self.__account_balance += amount
      #self.__account_balance = self.__ account_balance+amount
      Print(“Deposited â‚¹{}. New balance: â‚¹{}”.format(amount,
           Self.__account_balance)) 
    Else:
      Print(“Invalid deposit amount.”)

  Def withdraw(self, amount):
    If amount > 0 and amount <= self.__account_balance:
     Self.__account_balance -= amount
      #self.__account_balance = self.__account_balance – amount
     Print(“Withdrew â‚¹{}. New balance: â‚¹{}”.format(amount,
           Self.__account_balance))